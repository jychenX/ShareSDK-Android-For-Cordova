cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.sharesdk.cordova.share/www/ShareSDK.js",
        "id": "com.sharesdk.cordova.share.ShareSDK",
        "pluginId": "com.sharesdk.cordova.share",
        "clobbers": [
            "ShareSDK"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.sharesdk.cordova.share": "0.0.1",
    "cordova-plugin-whitelist": "1.2.2"
}
// BOTTOM OF METADATA
});