cordova.define("com.sharesdk.cordova.share.ShareSDK", function(require, exports, module) {   var cordova=require('cordova');

  var  ShareSDK =function(){

           Echo.prototype.echo=function(success,error,params){

                     cordova.exec(sucess,error,'Class','Method',params)//'Echo'对应我们在java文件中定义的类名，echo对应我们在这个类中调用的自定义方法，str是我们客户端传递给这个方法的参数，是个数组

           }

  }
  // var  sharesdk = new ShareSDK();
  //
  // module.exports = sharesdk;
});
